let products = [
  {
    id: 1,
    name: "White Shirt",
    size: "L",
    color: "white",
    price: 1200,
    image: "Cart1.jpg",
    description: "Causal & Formal Shirt",
  },
  {
    id: 2,
    name: "Lehenga",
    size: "M",
    color: "Black",
    price: 1500,
    image: "Cart2.jpg",
    description: "Ladies Party Wear Lehenga",
  },

  {
    id: 3,
    name: "Bridal Lehenga",
    size: "S",
    color: "Yellow",
    price: 1900,
    image: "Cart3.jpg",
    description: "Party Wear Bridal Lehenga",
  },

  {
    id: 4,
    name: "Designer Saree",
    size: "M",
    color: "Gray",
    price: 3000,
    image: "Cart4.jpg",
    description: "Designar Catalogues Saree",
  },

  {
    id: 5,
    name: "Semi-Formal Outfit",
    size: "S",
    color: "Brown",
    price: 1300,
    image: "Cart5.jpg",
    description: "Semi-Formal Outfit for Men",
  },

  {
    id: 6,
    name: "Green Mens Tshirt",
    size: "M",
    color: "Green",
    price: 1500,
    image: "Cart6.jpg",
    description: "Cotton Tshirt",
  },
  {
    id: 7,
    name: "Children Dresses",
    size: "L",
    color: "white & black",
    price: 1999,
    image: "Cart7.jpg",
    description: "Kids designer dresses",
  },
  {
    id: 8,
    name: "Kids Clothes",
    size: "M",
    color: "Pink",
    price: 799,
    image: "Cart8.jpg",
    description: "Jastore Girls Letter Love Flower Clothing Sets -Top + Short Skirt",
  },

  {
    id: 9,
    name: "Baby Suit",
    size: "S",
    color: "Black & White",
    price: 900,
    image: "Cart9.jpg",
    description: "New Baby Gentleman Suit Clothing Sets Kids Boy Clothes Fake Two Piece",
  },

  {
    id: 10,
    name: "Boys Kid Dress",
    size: "M",
    color: "Red",
    price: 655,
    image: "Cart10.jpg",
    description: "Party Wear Clothes",
  },

  {
    id: 11,
    name: "Top",
    size: "S",
    color: "Pink",
    price: 1300,
    image: "Cart11.jpg",
    description: "Ladies Fashion Top",
  },

  {
    id: 12,
    name: "Mens Fashion",
    size: "M",
    color: "Black & White",
    price: 1500,
    image: "Cart12.jpg",
    description: "European Mens Fashion Style",
  },
];

cart = [];

function displayProducts(productsData, who = "productwrapper") {
  let productsString = "";

  productsData.forEach(function (product, index) {
    let { id, name, image, color, description, price, size } = product;
	let addedcart = "Already added to Cart"; 
    if (who == "productwrapper") {
      productsString += ` <div class="product">
        <div class="prodimg">
          <img src="productimages/${image}" width="100%" />
        </div>
        <h3>${name}</h3>
        <p>Price : ${price}$</p>
        <p>Size : ${size}</p>
        <p>Color : ${color}</p>
        <p>${description}</p>
        <p>
          <button onclick="addToCart(${id})">Add to Cart</button>
        </p>
      </div>`;
	  
    } else if (who == "cart") {
      productsString += ` <div class="product">
        <div class="prodimg">
          <img src="productimages/${image}" width="100%" />
        </div>
        <h3>${name}</h3>
        <p>Price : ${price}$</p>
        <p>Size : ${size}</p>
        <p>Color : ${color}</p>
        <p>${description}</p>
		<h4><center>Already Added To Cart</h4>
        <p>
          <button onclick="removeFromCart(${id})">Remove from Cart</button>
        </p>
      </div>`;
	  
    } 
  });
   document.getElementById(who).innerHTML = productsString;
}

displayProducts(products);

function searchProduct(searchValue) {
  let searchedProducts = products.filter(function (product, index) {
    let searchString =
      product.name + " " + product.color + " " + product.description;

    return searchString.toUpperCase().indexOf(searchValue.toUpperCase()) != -1;
  });

  displayProducts(searchedProducts);
}

function getProductByID(productArray, id) {           //product based on id -array u want to get products,id u want to search
  return productArray.find(function (product) {
    return product.id == id;
  });
}
let counter = 0;
function addToCart(id) {
  // getting the product
  let pro = getProductByID(products, id);

  //   putting in cart
  cart.push(pro);
	counter += 1;
  displayProducts(cart, "cart");
  document.getElementById("demo").innerHTML = counter;
}

function removeFromCart(id) {
  // getting the index based on id
  let index = cart.findIndex(function (product) {
    return product.id == id;
  });

  //   removing from cart based on index
  cart.splice(index, 1);
  displayProducts(cart, "cart");
}