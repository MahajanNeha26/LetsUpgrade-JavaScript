let Employees = [
{
	name:"Neha Mahajan",
	age:24,
	city:"Pune",
	salary:300000,
},
{
	name:"Mohini Ingale",
	age:21,
	city:"Mumbai",
	salary:500000,
},
{
	name:"Rahul Waghulde",
	age:26,
	city:"Hyderabad",
	salary:250000,
},
{
	name:"Pavan Pangavhane",
	age:28,
	city:"Kolkata",
	salary:600000,
},
{
	name:"Gauravi Bharambe",
	age:25,
	city:"Delhi",
	salary:285500,
},
];


function display(superarray) {
	let tabledata = "";
	Employees.forEach(function(employee,index){
			let currentrow = `<tr> 
								<td>${index+1}</td>
								<td>${employee.name}</td>
								<td>${employee.age}</td>
								<td>${employee.city}</td>
								<td>${employee.salary}</td>
								<td><button onclick = "deletedata(${index})">Delete</button></td>
							  </tr>`;
			tabledata += currentrow;
	});
	document.getElementById("tablebody").innerHTML = tabledata;
}

display(Employees);

function deletedata(index){
	Employees.splice(index,1);
	display(Employees);
}

function searchByName() {
  let searchValue = document.getElementById("searchName").value;
  let newdata = Employees.filter(function (emp) {
    return (
      emp.name.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
    );
  });

  display(newdata);
}

function searchByCity() {
  let searchValue = document.getElementById("searchCity").value;
  let newdata = Employees.filter(function (emp) {
    return (
      emp.city.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
    );
  });

  display(newdata);
}


