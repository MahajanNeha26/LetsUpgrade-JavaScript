window.onload = function () {
  let buses = [
  ];

  if (localStorage.getItem("busoes") == null) {
    localStorage.setItem("busoes", JSON.stringify(buses));
  }
};


function display(superarray = undefined) {
  let tabledata = "";
  let busoes;
  if (superarray == undefined) {
    busoes = JSON.parse(localStorage.getItem("busoes"));
  } else {
    busoes = superarray;
  }

  busoes.forEach(function (busro, index) {
    let currentrow = `<tr>
      <td>${index + 1}</td>
      <td>${busro.name}</td>
      <td>${busro.source}</td>
      <td>${busro.destination}</td>
      <td>${busro.busnumber}</td>
      <td>${busro.passengercapacity}</td>
      </tr>`;

    tabledata += currentrow;
  });

  document.getElementsByClassName("tdata")[0].innerHTML = tabledata;
  //   document.getElementById("tdata").innerHTML = tabledata;
}

display();



function addbusinfo(event) {
  e.preventDefault();
  let bus = {};
  let name = document.getElementById("name").value;
  let source = document.getElementById("source").value;
  let destination = document.getElementById("destination").value;
  let busnumber = document.getElementById("busnumber").value;
  let passengercapacity = document.getElementById("passengercapacity").value;
  bus.name = name;
  bus.destination = destination;
  bus.busnumber = busnumber;
  bus.passengercapacity = Number(passengercapacity);

  buses.push(bus);

  let buses = JSON.parse(localStorage.getItem("buses"));
  buses.push(bus);
  localStorage.setItem("buses", JSON.stringify(buses));

  display();

  document.getElementById("name").value = "";
  document.getElementById("source").value = "";
  document.getElementById("destination").value = "";
  document.getElementById("busnumber").value = "";
  document.getElementById("passengercapacity").value = "";
}