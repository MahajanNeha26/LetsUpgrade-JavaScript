let xyz = ["HTML","CSS","JAVASCRIPT","C","C++"];
document.getElementById("demo").innerHTML = "<b>OUTPUT :</b>" + (xyz.indexOf("JAVASCRIPT"));