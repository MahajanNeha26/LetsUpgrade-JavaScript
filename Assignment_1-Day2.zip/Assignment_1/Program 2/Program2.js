let min = 43.25;
let secc = min * 60;
document.getElementById("demo").innerHTML = "<b>OUTPUT :</b>" + (secc);