let abc = ["Mango","Pineapple","Apple","Chickoo","Guava"];
document.getElementById("demo").innerHTML = "<b>OUTPUT :</b>" + abc.reverse();
