let txt = "Somesh went to School";
let abc = txt.search("o");
document.getElementById("demo").innerHTML = "<b>OUTPUT :</b>" + abc; 
/*OR*/
let xyz = txt.indexOf ("e",4);
document.getElementById("demo1").innerHTML = "<b>OUTPUT :</b>" + xyz; 