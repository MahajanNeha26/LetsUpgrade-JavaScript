function firstfunction(){
	const ele = document.getElementById("image1");
	const url1 = "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Ice_cream_with_whipped_cream%2C_chocolate_syrup%2C_and_a_wafer_%28cropped%29.jpg/1200px-Ice_cream_with_whipped_cream%2C_chocolate_syrup%2C_and_a_wafer_%28cropped%29.jpg";
	ele.src = url1;
}
function secondfunction(){
	const ele1 = document.getElementById("image1");
	const url2 = "https://content3.jdmagicbox.com/comp/thrissur/g5/9999px487.x487.180330231041.k6g5/catalogue/skei-plus-icecream-parlour-thrissur-ice-cream-parlours-ym5vvi9mn2.jpg";
	ele1.src = url2;
}
function thirdfunction(){
	const ele2 = document.getElementById("image1");
	const url3 = "https://4.imimg.com/data4/BQ/IA/MY-12203761/flavours-for-ice-creams-500x500.jpg";
	ele2.src = url3;
}