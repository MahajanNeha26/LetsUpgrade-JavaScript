let characteristics = [
{
	name:"Neha Mahajan",
	age:24,
	country:"India",
	hobbies:["Reading Books","Sketching","Cooking"],
},
{
	name:"Maria Dsouza",
	age:45,
	country:"Finland",
	hobbies:["Playing Batminton","Dancing"],
},
{
	name:"Rekha Patil",
	age:27,
	country:"Afganistan",
	hobbies:["Painting","Travelling"],
},
{
	name:"Tom Raht",
	age:36,
	country:"Switzerland",
	hobbies:["Travelling"],
},
{
	name:"Rahul Chaudhari",
	age:27,
	country:"India",
	hobbies:["Singing"],
},
{
	name:"Vivek Ingale",
	age:34,
	country:"India",
	hobbies:["Photography","Reading Books"],
},
];


characteristics.forEach(function (characteristics) {
 console.log (characteristics);
});